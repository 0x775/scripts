#coding=utf-8
"""
pip install mitmproxy==11.0.2
https://docs.mitmproxy.org/stable/addons-examples/
"""
import re
import time,json
import copy
import threading
import random
import asyncio
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from mitmproxy import options, http,ctx
from mitmproxy.tools.dump import DumpMaster


comments=[]

async def async_task(flow):
    random_time = random.randint(6, 15)
    await asyncio.sleep(random_time)  # 异步等待 5 秒
    #print("Async task completed!")
    ctx.master.commands.call("replay.client",flow)
# ------------------------- mitmproxy 抓包逻辑 -------------------------
class RequestCapture:
    def __init__(self):
        self.indexNum=0
        self.triggered = False
        self.captured_requests = []

    def request(self, flow: http.HTTPFlow):
        req = {
            "method": flow.request.method,
            "url": flow.request.url,
            "headers": dict(flow.request.headers),
            "body": flow.request.content.decode("utf-8", errors="ignore"),
        }
        self.captured_requests.append(req)

    def response(self, flow: http.HTTPFlow):
        #print(flow.request.url)
        if "comment/list" in flow.request.url:
            print("列表请求:"+flow.request.url[:120])
            # 检查响应是否为 JSON
            content_type = flow.response.headers.get("Content-Type", "").lower()
            try:
                # 解析并打印 JSON 数据
                body = flow.response.content.decode("utf-8")
                #print(body)
                json_data = json.loads(body)
                print("""数据总量:%d,  cursor:%d  has_more:%d""" %(json_data.get("total",0),json_data.get("cursor",0),json_data.get("has_more",0)))
                #print(f"\n===== 捕获到目标接口: {flow.request.url} =====")
                #print(json.dumps(json_data, indent=2, ensure_ascii=False))
                #data=json.dumps(json_data, indent=2, ensure_ascii=False)
                #只要7天以内的数据
                current_time = time.time()
                days_ago_ts = current_time - 7 * 24 * 3600
                comment_list=json_data.get("comments",[])
                for item in comment_list:
                    try:
                        create_time = item["create_time"]
                        #超过7天时间的数据丢弃掉
                        if create_time < days_ago_ts:
                            continue
                        c={}
                        c["cid"]=item["cid"]
                        c["text"]=item["text"]
                        c["aweme_id"]=item["aweme_id"]
                        c["create_time"]=item["create_time"]
                        c["post_time"]=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(c["create_time"]))
                        c["user_uid"]=item.get("user",{}).get("uid","")
                        c["user_nickname"]=item.get("user",{}).get("nickname","")
                        avatar_thumb=""
                        tmp=item.get("user",{}).get("avatar_thumb",{}).get("url_list",[])
                        if len(tmp) >0:
                            avatar_thumb = tmp[0]
                        c["user_avatar"]=avatar_thumb
                        c["user_sec_uid"]=item.get("user",{}).get("sec_uid","")
                        c["ip_label"]=item["ip_label"]
                        #print(c)
                        print(c["post_time"],"\t",c["user_nickname"],"\t",c["text"])
                    except Exception as e:
                        print("解析读取数据出错:",e)
                #print("--------->>> 自动请求 +++++++++++++++")
                if json_data.get("has_more",0)==1:
                    print("还有更多,自动请求..")
                    cursor = json_data.get("cursor",0)
                    cursor = int(cursor)+10
                    print("尝试 cursor:",cursor)
                    
                    new_flow = flow.copy()
                    new_flow.request.query["cursor"] = cursor
                    if "cursor=" in new_flow.request.url:
                        cursor_value = int(re.search(r"cursor=(\d+)", new_flow.request.url).group(1))
                        new_flow.request.url = new_flow.request.url.replace(f"cursor={cursor_value}", f"cursor={cursor}")
                    else:
                        separator = "&" if "?" in url else "?"
                        new_flow.request.url = new_flow.request.url + f"{separator}cursor=10"
                    asyncio.create_task(async_task([new_flow]))
                    #print("Task started, but code continues running!")
            except Exception as e:
                print(e)

    def send_request(self, request: http.Request) -> None:
        http.request(
            method=request.method,
            url=request.url,
            content=request.raw_content,
            headers=request.headers
        )

# ------------------------- 启动 mitmproxy -------------------------
async def start_mitmproxy(capture):
    opts = options.Options(
        listen_port=8080,
        ssl_insecure=True  # 忽略证书错误（测试环境用）
    )
    master = DumpMaster(opts, with_termlog=False,with_dumper=False)
    master.addons.add(capture)
    print("mitmproxy 启动在 8080 端口")
    await master.run()

def run_mitmproxy(capture):
    # 创建新的事件循环
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(start_mitmproxy(capture))

capture = RequestCapture()
# 启动 mitmproxy 线程
mitm_thread = threading.Thread(target=run_mitmproxy, args=(capture,), daemon=True)
mitm_thread.start()
time.sleep(3)  # 等待代理启动

# 设置ChromeDriver路径
service = Service(executable_path='D:\\project\\Auto\\chromedriver-win64\\chromedriver.exe')  # 例如：/usr/local/bin/chromedriver

#设置参数
chrome_options = Options()
#m_options.add_argument("--headless")  # 启用无头模式
chrome_options.add_argument("--proxy-server=127.0.0.1:8080")
chrome_options.add_argument('verify=False') # 跳过SSL证书验证
chrome_options.add_argument('--ignore-certificate-errors')  # 忽略证书错误
chrome_options.add_argument('--ignore-ssl-errors')         # 忽略SSL错误
#禁用自动化提示
chrome_options.add_argument('--disable-infobars')
chrome_options.add_argument('--disable-extensions')
chrome_options.add_argument('--disable-popup-blocking')
chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
chrome_options.add_experimental_option("useAutomationExtension", False)

# 启动浏览器
driver = webdriver.Chrome(service=service,options=chrome_options)
# 打开网页
driver.get("https://www.douyin.com")

while True:
    time.sleep(1)
    #print("..sleep..")
time.sleep(3000*1000)