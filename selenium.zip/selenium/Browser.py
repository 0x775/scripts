#coding=utf-8
"""
pip install mitmproxy==11.0.2
https://docs.mitmproxy.org/stable/addons-examples/
"""
import time,json
import copy
import threading
import asyncio
import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (TimeoutException, 
                                      NoSuchElementException,
                                      StaleElementReferenceException,
                                      ElementClickInterceptedException)
from mitmproxy import options, http,ctx
from mitmproxy.tools.dump import DumpMaster


class RequestCapture:
    def __init__(self):
        self.index=0
    def request(self, flow: http.HTTPFlow):
        #请求
        pass
    def response(self, flow: http.HTTPFlow):
        #响应
        pass


# ------------------------- 启动 mitmproxy -------------------------
async def start_mitmproxy(capture):
    opts = options.Options(
        listen_port=8080,
        ssl_insecure=True  # 忽略证书错误（测试环境用）
    )
    master = DumpMaster(opts, with_termlog=False,with_dumper=False)
    master.addons.add(capture)
    print("mitmproxy 启动在 8080 端口")
    await master.run()

def run_mitmproxy(capture):
    # 创建新的事件循环
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(start_mitmproxy(capture))

def start_proxy(capture):
    mitm_thread = threading.Thread(target=run_mitmproxy, args=(capture,), daemon=True)
    mitm_thread.start()
    time.sleep(3)  # 等待代理启动

class Browser:
    def __init__(self):
        self.driver = None
        self.max_retries = 3
        self.base_wait_time = 10
        self.screenshot_dir = "screenshots/"

    def init(self,proxy=False):
        """初始化浏览器驱动"""
        try:
            service = Service(executable_path='D:\\project\\Auto\\chromedriver-win64\\chromedriver.exe')
            #设置参数
            chrome_options = Options()
            #m_options.add_argument("--headless")  # 启用无头模式
            if proxy:
                chrome_options.add_argument("--proxy-server=127.0.0.1:8080")
            chrome_options.add_argument('verify=False') # 跳过SSL证书验证
            chrome_options.add_argument('--ignore-certificate-errors')  # 忽略证书错误
            chrome_options.add_argument('--ignore-ssl-errors')         # 忽略SSL错误
            #禁用自动化提示
            chrome_options.add_argument('--disable-infobars')
            chrome_options.add_argument('--disable-extensions')
            chrome_options.add_argument('--disable-popup-blocking')
            chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
            chrome_options.add_experimental_option("useAutomationExtension", False)
            self.driver = webdriver.Chrome(service=service,options=chrome_options)
            self.driver.maximize_window()
            return True
        except Exception as e:
            print(f"无法启动浏览器: {e}")
            return False

    def take_screenshot(self, name):
        """截取屏幕截图"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{self.screenshot_dir}{name}_{timestamp}.png"
        try:
            self.driver.save_screenshot(filename)
            print(f"已保存截图: {filename}")
        except Exception as e:
            print(f"截图失败: {e}")

    def find_element(self, by, value, timeout=None, retries=None):
        """
        安全查找元素，带重试机制
        :param by: 定位方式 (By.ID, By.XPATH等)
        :param value: 定位值
        :param timeout: 单次等待超时时间(秒)
        :param retries: 重试次数
        :return: 找到的元素或None
        """
        timeout = timeout or self.base_wait_time
        retries = retries or self.max_retries
        
        for attempt in range(retries):
            try:
                element = WebDriverWait(self.driver, timeout).until(EC.presence_of_element_located((by, value)))
                return element
            except (TimeoutException, NoSuchElementException) as e:
                print(f"第 {attempt + 1} 次尝试查找元素失败: {value} (等待 {timeout}秒)")
                if attempt == retries - 1:  # 最后一次尝试失败
                    self.take_screenshot(f"element_not_found_{value}")
                    return None
                time.sleep(2)  # 重试前等待
            except StaleElementReferenceException:
                print(f"元素引用过期，重新尝试查找: {value}")
                time.sleep(1)
        return None

    def click(self, by, value, timeout=None, retries=None):
        """
        :param by: 定位方式
        :param value: 定位值
        :return: 是否点击成功
        """
        timeout = timeout or self.base_wait_time
        retries = retries or self.max_retries
        
        for attempt in range(retries):
            element = self.find_element(by, value, timeout)
            if not element:
                return False
                
            try:
                # 滚动元素到视图
                self.driver.execute_script("arguments[0].scrollIntoViewIfNeeded(true);", element)
                time.sleep(0.5)
                
                # 等待元素可点击
                WebDriverWait(self.driver, timeout).until(
                    EC.element_to_be_clickable((by, value)))
                
                element.click()
                return True
            
            except Exception as e:
                print(f"点击元素失败: {e} (尝试 {attempt + 1}/{retries})")
                self.take_screenshot(f"click_failed_{value}")
                time.sleep(1)
        
        return False

    def wait_for_page_load(self, timeout=30):
        """等待页面完全加载"""
        try:
            WebDriverWait(self.driver, timeout).until(
                lambda d: d.execute_script("return document.readyState") == "complete")
            return True
        except TimeoutException:
            print(f"页面加载超时 ({timeout}秒)")
            self.take_screenshot("page_load_timeout")
            return False

    # 保存 Cookies 到文件
    def save_cookies(self, file_path):
        cookies = self.driver.get_cookies()
        with open(file_path, 'w') as f:
            json.dump(cookies, f)

    # 从文件加载 Cookies
    def load_cookies(self, file_path):
        with open(file_path, 'r') as f:
            cookies = json.load(f)
        self.driver.delete_all_cookies()  # 清除旧 Cookies（如果有）
        for cookie in cookies:
            self.driver.add_cookie(cookie)


if __name__ == "__main__":
    capture = RequestCapture()
    start_proxy(capture)
    browser = Browser()
    browser.init(proxy=True)
    browser.driver.get("https://www.douyin.com")
    while True:
        time.sleep(3)
        #TODO ...
"""

代理抓包的启动方法(默认是同步,改成异步)
async def async_task(flow):
    random_time = random.randint(6, 15)
    await asyncio.sleep(random_time)  # 异步等待 5 秒
    ctx.master.commands.call("replay.client",flow)
# ------------------------- mitmproxy 抓包逻辑 -------------------------
class RequestCapture:
    def __init__(self):
        self.indexNum=0

    def request(self, flow: http.HTTPFlow):
        req = {
            "method": flow.request.method,
            "url": flow.request.url,
            "headers": dict(flow.request.headers),
            "body": flow.request.content.decode("utf-8", errors="ignore"),
        }
        self.captured_requests.append(req)

    def response(self, flow: http.HTTPFlow):
        #print(flow.request.url)
        if "comment/list" in flow.request.url:
            print("列表请求:"+flow.request.url[:120])
            # 检查响应是否为 JSON
            content_type = flow.response.headers.get("Content-Type", "").lower()
            try:
                # 解析并打印 JSON 数据
                body = flow.response.content.decode("utf-8")
                json_data = json.loads(body)
                #print(f"\n===== 捕获到目标接口: {flow.request.url} =====")
                #print(json.dumps(json_data, indent=2, ensure_ascii=False))
                #print("--------->>> 自动请求 +++++++++++++++")
                if json_data.get("has_more",0)==1:
                    print("还有更多,自动请求..")
                    cursor = json_data.get("cursor",0)
                    cursor = int(cursor)+10
                    print("尝试 cursor:",cursor)
                    
                    new_flow = flow.copy()
                    new_flow.request.query["cursor"] = cursor
                    if "cursor=" in new_flow.request.url:
                        cursor_value = int(re.search(r"cursor=(\d+)", new_flow.request.url).group(1))
                        new_flow.request.url = new_flow.request.url.replace(f"cursor={cursor_value}", f"cursor={cursor}")
                    else:
                        separator = "&" if "?" in url else "?"
                        new_flow.request.url = new_flow.request.url + f"{separator}cursor=10"
                    asyncio.create_task(async_task([new_flow]))
                    #print("Task started, but code continues running!")
            except Exception as e:
                print(e)


#-------++++
capture = RequestCapture()
# 启动 mitmproxy 线程
mitm_thread = threading.Thread(target=run_mitmproxy, args=(capture,), daemon=True)
mitm_thread.start()
time.sleep(3)  # 等待代理启动

"""
