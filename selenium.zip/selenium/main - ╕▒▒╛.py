#coding=utf-8
"""
pip install mitmproxy==11.0.2
https://docs.mitmproxy.org/stable/addons-examples/
"""
import time,json
import copy
import threading
import asyncio
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from mitmproxy import options, http,ctx
from mitmproxy.tools.dump import DumpMaster


comments=[]
# ------------------------- mitmproxy 抓包逻辑 -------------------------
class RequestCapture:
    def __init__(self):
        self.triggered = False
        self.captured_requests = []

    def request(self, flow: http.HTTPFlow):
        req = {
            "method": flow.request.method,
            "url": flow.request.url,
            "headers": dict(flow.request.headers),
            "body": flow.request.content.decode("utf-8", errors="ignore"),
        }
        self.captured_requests.append(req)

    def response(self, flow: http.HTTPFlow):
        #print(flow.request.url)
        if "comment/list" in flow.request.url:
            print("捕获请求:"+flow.request.url)
            # 检查响应是否为 JSON
            content_type = flow.response.headers.get("Content-Type", "").lower()
            try:
                # 解析并打印 JSON 数据
                body = flow.response.content.decode("utf-8")
                json_data = json.loads(body)
                print("""数据总量:%d,  cursor:%d  has_more:%d""" %(json_data.get("total",0),json_data.get("cursor",0),json_data.get("has_more",0)))
                #print(f"\n===== 捕获到目标接口: {flow.request.url} =====")
                #print(json.dumps(json_data, indent=2, ensure_ascii=False))
                #data=json.dumps(json_data, indent=2, ensure_ascii=False)
                #只要7天以内的数据
                current_time = time.time()
                days_ago_ts = current_time - 7 * 24 * 3600
                comment_list=json_data.get("comments",[])
                for item in comment_list:
                    try:
                        create_time = item["create_time"]
                        #超过7天时间的数据丢弃掉
                        if create_time < days_ago_ts:
                            continue
                        c={}
                        c["cid"]=item["cid"]
                        c["text"]=item["text"]
                        c["aweme_id"]=item["aweme_id"]
                        c["create_time"]=item["create_time"]
                        c["user_uid"]=item.get("user",{}).get("uid","")
                        c["user_nickname"]=item.get("user",{}).get("nickname","")
                        avatar_thumb=""
                        tmp=item.get("user",{}).get("avatar_thumb",{}).get("url_list",[])
                        if len(tmp) >0:
                            avatar_thumb = tmp[0]
                        c["user_avatar"]=avatar_thumb
                        c["user_sec_uid"]=item.get("user",{}).get("sec_uid","")
                        c["ip_label"]=item["ip_label"]
                        print(c)
                    except Exception as e:
                        print("解析读取数据出错:",e)
                print("--------->>> test.reply+++++++++++++++")
                if json_data.get("has_more",0)==1 and not self.triggered:
                    self.triggered = True
                    print("test..更多")
                    
                    # 克隆完整请求上下文（关键步骤）
                    new_flow = flow.copy()
               
                    """
                    # 修改参数的 Windows 安全操作
                    new_params = []
                    for key, value in new_flow.request.query.items(multi=True):
                        if key == "cursor":
                            new_params.append((key, "10"))  # 替换 page 参数
                        else:
                            new_params.append((key, value))
                    new_flow.request.query = new_params
                    """
                    #new_flow.request.query["cursor"] = "10"
                    #new_flow.request.data.rebuild()
                    # 符合 11.0.2 参数结构的调用方式

                    print(new_flow)
                    ctx.master.commands.call(
                        "replay.client", 
                        [new_flow]
                    )
                    print(333)
                    # 修改页码参数
                    #new_query = new_flow.request.query.copy()
                    #new_query["cursor"] = int(new_query["cursor"])+10
                    #new_flow.request.query = new_query

                    # 假设原始请求是POST,JSON 格式
                    #body = json.loads(new_request.content)
                    #body["page"] = 2
                    #new_request.content = json.dumps(body).encode()

                    #self.send_request(new_request)
                    #ctx.master.replay_request(new_flow)
                    time.sleep(1)

            except Exception as e:
                print(e)

    def send_request(self, request: http.Request) -> None:
        http.request(
            method=request.method,
            url=request.url,
            content=request.raw_content,
            headers=request.headers
        )

# ------------------------- 启动 mitmproxy -------------------------
async def start_mitmproxy(capture):
    opts = options.Options(
        listen_port=8080,
        ssl_insecure=True  # 忽略证书错误（测试环境用）
    )
    master = DumpMaster(opts, with_termlog=False,with_dumper=False)
    master.addons.add(capture)
    print("mitmproxy 启动在 8080 端口")
    await master.run()

def run_mitmproxy(capture):
    # 创建新的事件循环
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(start_mitmproxy(capture))

capture = RequestCapture()
# 启动 mitmproxy 线程
mitm_thread = threading.Thread(target=run_mitmproxy, args=(capture,), daemon=True)
mitm_thread.start()
time.sleep(3)  # 等待代理启动

# 设置ChromeDriver路径
service = Service(executable_path='D:\\project\\Auto\\chromedriver-win64\\chromedriver.exe')  # 例如：/usr/local/bin/chromedriver

#设置参数
chrome_options = Options()
#m_options.add_argument("--headless")  # 启用无头模式
chrome_options.add_argument("--proxy-server=127.0.0.1:8080")
chrome_options.add_argument('verify=False') # 跳过SSL证书验证
chrome_options.add_argument('--ignore-certificate-errors')  # 忽略证书错误
chrome_options.add_argument('--ignore-ssl-errors')         # 忽略SSL错误
#禁用自动化提示
chrome_options.add_argument('--disable-infobars')
chrome_options.add_argument('--disable-extensions')
chrome_options.add_argument('--disable-popup-blocking')
chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
chrome_options.add_experimental_option("useAutomationExtension", False)

# 启动浏览器
driver = webdriver.Chrome(service=service,options=chrome_options)
# 打开网页
driver.get("https://www.douyin.com")
cookies_file = "cookies.json"

# 保存 Cookies 到文件
def save_cookies(driver, file_path):
    cookies = driver.get_cookies()
    with open(file_path, 'w') as f:
        json.dump(cookies, f)

# 从文件加载 Cookies
def load_cookies(driver, file_path):
    with open(file_path, 'r') as f:
        cookies = json.load(f)
    driver.delete_all_cookies()  # 清除旧 Cookies（如果有）
    for cookie in cookies:
        driver.add_cookie(cookie)

def FindByElement(element,isClick=False,wtime=10):
    try:
        if element.startswith("#"):
            el = WebDriverWait(driver, wtime).until(
                EC.presence_of_element_located((By.ID,element))
            )
        elif element.startswith("//"):
            el = WebDriverWait(driver, wtime).until(
                EC.presence_of_element_located((By.XPATH,element))
            )
        elif element.find("=") !=-1:
            el = WebDriverWait(driver, wtime).until(
                EC.presence_of_element_located((By.CSS_SELECTOR,element))
            )
        else:
            el = WebDriverWait(driver, wtime).until(
                EC.presence_of_element_located((By.CLASS_NAME,element))
            )
        if isClick:
            el.click()
        return el
    except Exception as e:
        #print("FindByElement.Error: ",e)
        return None

def FindByXpath(element,isClick=False,wtime=10):
    try:
        el = WebDriverWait(driver, wtime).until(
            EC.presence_of_element_located((By.XPATH,element))
        )
        if isClick:
            el.click()
        return el
    except Exception as e:
        return None


try:
    time.sleep(6)
    load_cookies(driver, cookies_file)
    #driver.refresh()  # 刷新页面使 Cookies 生效
    login_text_xpath = '''
        //svg[@id='svg_icon_avatar']
        /following-sibling::p[text()='登录']
    '''
    el = FindByXpath(login_text_xpath)
    if el==None:
        print("已通过 Cookies 恢复登录状态")
    else:
        print("还是需要登录的")
        #return driver
except FileNotFoundError:
    print("未找到 Cookies 文件，需手动登录")

"""
loginBox = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.ID, "login-panel-new"))
)
print(loginBox)
"""

el = FindByElement("#login-panel-new")
print(el,"1")
el = FindByElement("lR1QBof5---",True)
print(el,"2")
el = FindByElement("semi-button-primary",True)
print(el,"3")
el = FindByElement("//input[@data-e2e='searchbar-input']")
if el:
    print("find.input")
    el.send_keys("丁哥说法")
    """
    el=FindByElement("button[data-e2e='searchbar-button']")
    if el:
        el.click()
    """
else:
    print("not.find.input")


while True:
    time.sleep(20)
    login_text_xpath = '''
        //svg[@id='svg_icon_avatar']
        /following-sibling::p[text()='登录']
    '''
    el = FindByXpath(login_text_xpath)
    if el:
        print("还是未登录状态")
    else:
        print("已登录,保存cookies")
        save_cookies(driver, cookies_file)
        break






"""
try:
    # 第一步：等待父元素出现（最多等10秒）
    parent = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "login-panel-new"))  # 替换为实际父元素定位方式
    )

    # 第二步：在父元素内部查找子元素（显式等待）
    try:
        # 方法1：直接查找子元素（不等待）
        # child = parent.find_element(By.CLASS_NAME, "target_class")

        # 方法2：显式等待子元素存在（推荐）
        child = WebDriverWait(driver, 5).until(
            lambda d: parent.find_element(By.CLASS_NAME, "lR1QBof5")  # 替换子元素定位
        )

        # 第三步：检查是否存在并点击
        child.click()
        print("成功点击子元素")
    
    except TimeoutException:
        print("子元素未找到")
    except NoSuchElementException:
        print("子元素不存在")

except TimeoutException:
    print("父元素未找到")
"""

# lR1QBof5


"""
# 显式等待元素加载（最多等10秒）
search_box = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.ID, "kw"))  # 百度搜索框的ID通常是"kw"
)

# 输入文本
search_box.send_keys("Python Selenium")

# 找到搜索按钮并点击（百度搜索按钮ID通常是"su"）
search_button = driver.find_element(By.ID, "su")
search_button.click()

# 等待结果加载（根据实际需求调整）
WebDriverWait(driver, 10).until(
    EC.title_contains("Python Selenium")
)

# 关闭浏览器
driver.quit()
"""
time.sleep(3000*1000)