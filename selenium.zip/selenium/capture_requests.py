# capture_requests.py
from mitmproxy import http

# 存储捕获的请求
captured_requests = []

def request(flow: http.HTTPFlow):
    """捕获请求"""
    req = {
        "method": flow.request.method,
        "url": flow.request.url,
        "headers": dict(flow.request.headers),
        "query": dict(flow.request.query),
        "body": flow.request.content.decode("utf-8", errors="ignore"),
    }
    captured_requests.append(req)
    print(f"捕获请求: {req['method']} {req['url']}")

def response(flow: http.HTTPFlow):
    """捕获响应"""
    for req in captured_requests:
        if req["url"] == flow.request.url:
            req["response"] = {
                "status_code": flow.response.status_code,
                "headers": dict(flow.response.headers),
                "body": flow.response.content.decode("utf-8", errors="ignore"),
            }