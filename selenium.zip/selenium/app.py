#coding=utf-8
import time
from mitmproxy import options, http,ctx
from Browser import Browser,start_proxy
from selenium.webdriver.common.by import By

class RequestCapture:
    def __init__(self):
        self.indexNum=0
        self.triggered = False
        self.captured_requests = []

    def request(self, flow: http.HTTPFlow):
        req = {
            "method": flow.request.method,
            "url": flow.request.url,
            "headers": dict(flow.request.headers),
            "body": flow.request.content.decode("utf-8", errors="ignore"),
        }
        self.captured_requests.append(req)

    def response(self, flow: http.HTTPFlow):
        #print(flow.request.url)
        if "comment/list" in flow.request.url:
            print("列表请求:"+flow.request.url[:120])
            # 检查响应是否为 JSON
            content_type = flow.response.headers.get("Content-Type", "").lower()
            try:
                # 解析并打印 JSON 数据
                body = flow.response.content.decode("utf-8")
                #print(body)
                json_data = json.loads(body)
                print("""数据总量:%d,  cursor:%d  has_more:%d""" %(json_data.get("total",0),json_data.get("cursor",0),json_data.get("has_more",0)))
                #print(f"\n===== 捕获到目标接口: {flow.request.url} =====")
                #print(json.dumps(json_data, indent=2, ensure_ascii=False))
                #data=json.dumps(json_data, indent=2, ensure_ascii=False)
                #只要7天以内的数据
                current_time = time.time()
                days_ago_ts = current_time - 7 * 24 * 3600
                comment_list=json_data.get("comments",[])
                for item in comment_list:
                    try:
                        create_time = item["create_time"]
                        #超过7天时间的数据丢弃掉
                        if create_time < days_ago_ts:
                            continue
                        c={}
                        c["cid"]=item["cid"]
                        c["text"]=item["text"]
                        c["aweme_id"]=item["aweme_id"]
                        c["create_time"]=item["create_time"]
                        c["post_time"]=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(c["create_time"]))
                        c["user_uid"]=item.get("user",{}).get("uid","")
                        c["user_nickname"]=item.get("user",{}).get("nickname","")
                        avatar_thumb=""
                        tmp=item.get("user",{}).get("avatar_thumb",{}).get("url_list",[])
                        if len(tmp) >0:
                            avatar_thumb = tmp[0]
                        c["user_avatar"]=avatar_thumb
                        c["user_sec_uid"]=item.get("user",{}).get("sec_uid","")
                        c["ip_label"]=item["ip_label"]
                        #print(c)
                        print(c["post_time"],"\t",c["user_nickname"],"\t",c["text"])
                    except Exception as e:
                        print("解析读取数据出错:",e)
                #print("--------->>> 自动请求 +++++++++++++++")
                if json_data.get("has_more",0)==1:
                    print("还有更多,自动请求..")
                    cursor = json_data.get("cursor",0)
                    cursor = int(cursor)+10
                    print("尝试 cursor:",cursor)
                    
                    new_flow = flow.copy()
                    new_flow.request.query["cursor"] = cursor
                    if "cursor=" in new_flow.request.url:
                        cursor_value = int(re.search(r"cursor=(\d+)", new_flow.request.url).group(1))
                        new_flow.request.url = new_flow.request.url.replace(f"cursor={cursor_value}", f"cursor={cursor}")
                    else:
                        separator = "&" if "?" in url else "?"
                        new_flow.request.url = new_flow.request.url + f"{separator}cursor=10"
                    asyncio.create_task(async_task([new_flow]))
                    #print("Task started, but code continues running!")
            except Exception as e:
                print(e)

    def send_request(self, request: http.Request) -> None:
        http.request(
            method=request.method,
            url=request.url,
            content=request.raw_content,
            headers=request.headers
        )

print("start..")
capture = RequestCapture()
start_proxy(capture)
browser = Browser()
browser.init(proxy=True)
browser.driver.get("https://www.douyin.com")

while True:
    loginPanelNew = browser.find_element(By.ID, "login-panel-new")
    if loginPanelNew:
        print("需要登录")
        browser.load_cookies("cookies.json")
        browser.driver.refresh()
    time.sleep(3)
    pass


